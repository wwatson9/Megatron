const chatBox = document.getElementById('chatbot-messages'); // Adjusted to match your HTML
const chatInput = document.getElementById('chatbot-input'); // Input field for the user
const chatSend = document.getElementById('chatbot-send'); // Button to send the message

chatSend.addEventListener('click', () => {
    const userMessage = chatInput.value;
    if (userMessage.trim() === "") return; // Avoid empty messages
    addMessageToChat(userMessage, 'user-message'); // Add user message to chat
    chatInput.value = ''; // Clear input field
    
    const botResponse = getBotResponse(userMessage); // Get bot response
    addMessageToChat(botResponse, 'bot-message'); // Add bot response to chat
});

function addMessageToChat(message, messageClass) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('chat-message', messageClass);
    messageElement.textContent = message; // Set the text of the message
    chatBox.appendChild(messageElement); // Add message to the chat box
    chatBox.scrollTop = chatBox.scrollHeight; // Scroll to bottom
}

function getBotResponse(message) {
    const lowerCaseMessage = message.toLowerCase(); // Convert message to lowercase for matching

    if (lowerCaseMessage.includes('housing')) {
        return "For housing assistance, check out the Apartment Guide and Low Income Housing links.";
    } else if (lowerCaseMessage.includes('job') || lowerCaseMessage.includes('employment')) {
        return "You can find job postings on Indeed and LinkedIn.";
    } else if (lowerCaseMessage.includes('debt')) {
        return "Visit the National Foundation for Credit Counseling for help with debt.";
    } else if (lowerCaseMessage.includes('addiction')) {
        return "For addiction support, check out SAMHSA and the National Institute on Drug Abuse.";
    } else if (lowerCaseMessage.includes('mental health')) {
        return "Mental Health America and NAMI are great resources for mental health support.";
    } else if (lowerCaseMessage.includes('domestic')) {
        return "If you are facing domestic issues, reach out to the National Domestic Violence Hotline.";
    } else if (lowerCaseMessage.includes('food')) {
        return "Feeding America and FoodPantries.org can help with food assistance.";
    } else {
        return "I'm here to help! Please ask about housing, jobs, debt, addiction, mental health, domestic issues, or food assistance.";
    }
}
