const firebaseConfig = {
    apiKey: "AIzaSyD0Z8opYotm9mqbSaFYbJ3uYZ0pYf7eL58",
    authDomain: "cpt-help-hotline.firebaseapp.com",
    databaseURL: "https://cpt-help-hotline-default-rtdb.firebaseio.com/",
    projectId: "cpt-help-hotline",
    sotrageBucket: "cpt-help-hotline.appspot.com",
    messagingSenderId: "766345167266",
    appId: "1:766345167266:web:862833971279f1e5ebf2fb",
};

//initialize firebase
firebase.initializeApp(firebaseConfig);

// reference your database
var contactFormDB = firebase.database().ref('contactForm')

document.getElementById('contactForm').addEventListener('sumbit', submitForm);

function submitForm(e){
    e.preventDefault();

    var email = getElementVal('email');
    var crime = getElementVal('crime-type');
    var race = getElementVal('race');
    var top = getElementVal('top');
    var bottom = getElementVal('bottom');
    var shoes = getElementVal('shoes');
    var hair = getElementVal('hair');
    var hairT = getElementVal('hairT');
    var image = getElementVal('file-input');
    var vehicle = getElementVal('vehicle-make');
    var vehiclem = getElementVal('vehicle-model');
    var vehiclec = getElementVal('vehicle-color');
    var license = getElementVal('license-plate');

    saveMessages(email, crime, race, top, bottom, shoes, hair, hairT, image, vehicle, vehiclem, cehiclec, liscence);

    document.querySelector(".alert").style.display = "block";
    
    setTimeout(() => {
        document.querySelector(".alert").style.display = "none";
      }, 3000);

      document.getElementById("contactForm").reset();

}

const saveMessages = (email, crime, race, top, bottom, shoes, hair, hairT, image, vehicle, vehiclem, cehiclec, liscence) => {
    var newContactForm = contactFormDB.push();

    newContactForm.set({
        email: email,
        crime: crime-type,
        race : race,
        top : top,
        bottom : bottom,
        shoes : shoes,
        hair : hair,
        hairT : hairT,
        image : file-input, 
        vehicle : vehicle-make,
        vehiclem : vehicle-model,
        vehiclec : vehicle-color,
        license : license-plate,
    });
};

const getElementVal = (id) => {
    return document.getElementById(id).value;
};